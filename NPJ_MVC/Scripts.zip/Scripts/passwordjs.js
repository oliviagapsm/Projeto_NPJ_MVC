﻿function myFunction() {
    var x = document.getElementById("myPass");
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
}
function myFunctionConfirmPass() {
    var x = document.getElementById("myConfirmPass");
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
}
function myFunctionConf() {
    var x = document.getElementById("myPassConf");
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
}
function myFunctionPass() {
    var x = document.getElementById("myPassActual");
    if (x.type === "password") {
        x.type = "text";
    } else {
        x.type = "password";
    }
}